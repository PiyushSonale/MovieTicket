import React, { Component } from 'react';
import {Card} from 'react-bootstrap';

class Footer extends Component {
    render() {
        return (
           
         
            <div class="footer-copyright text-center py-3" >© 2022 Copyright:
              <a href="./Home">Online Movie Ticket Booking</a>
            </div>
           
          
            
        );
    }
}

export default Footer;