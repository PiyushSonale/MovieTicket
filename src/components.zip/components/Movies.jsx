import React, { Component } from 'react';

class Movies extends Component {
    render() {
        return (
            <div>
                <h1>welcome to movies page</h1>
            </div>
        );
    }
}

export default Movies;